# EECS 348 Lab 10 — String‑Based Calculator

This repository contains a solution for the University of Kansas EECS 348 (Software Engineering I) Fall 2025 Lab 10, which focuses on performing arithmetic on numbers represented as strings.  The objective is to validate and add (and optionally multiply) decimal numbers without converting them to built‑in numeric types.

## Files

| File                     | Description |
|-------------------------|-------------|
| `main.cpp`              | Entry point of the program; reads test cases from a user‑specified text file, validates each pair of numbers, and prints the results. |
| `string_calculator.h`   | Declarations for helper functions used to validate and manipulate string‑based numbers. |
| `string_calculator.cpp` | Implementations of the functions declared in `string_calculator.h`.  These include routines to check if a string is a valid double, normalize its representation, compare magnitudes, and perform addition. |
| `Makefile`              | Builds the program into an executable named `calculator` using `g++` with C++17.  Run `make` to compile and `make clean` to remove build artefacts. |
| `README.md`             | This document. |

## Building and Running

To compile the program, ensure you have a C++ compiler that supports at least C++17.  Then run:

```sh
make
```

This will produce an executable called `calculator`.  To run the program, provide it with the path to a file containing test cases.  Each line in the file must contain two whitespace‑separated strings representing numeric values.  For example:

```txt
123 456
123.456 +1
0007.5 -3.2
-1 -1

```

When you run the program, it prompts for the filename:

```sh
$ ./calculator
Enter the path to the test case file: testcases.txt
Line 1: 123 + 456 = 579
Line 2: 123.456 + +1 = 124.456
Line 3: 0007.5 + -3.2 = 4.3
Line 4: -1 + -1 = -2
```

The program reports invalid inputs and continues processing the remaining lines.  All arithmetic is performed using string operations; no values are ever converted to `double` or `float`.

## Notes

* The program only supports addition.  Multiplication can be added using a similar strategy if desired.
* The implementation intentionally avoids using exceptions or regular expressions to validate inputs.  Instead, it relies on character‑wise checks as described in the assignment specification.
